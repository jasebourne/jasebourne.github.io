import React from 'react'
export default function Hero(){return(<section className='text-center'><h2>Plan your build</h2></section>)}