import React from 'react'
export default function Header(){return(<header className='py-4'><h1>Survivor.io Tools</h1></header>)}